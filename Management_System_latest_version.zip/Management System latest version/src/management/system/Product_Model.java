/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author someone
 */
public class Product_Model extends AbstractTableModel{
    
    private ArrayList<Product> array;
    private int newid;
    
    public Product_Model(){
        super();
        array = new ArrayList<Product>();
        newid = 001;
        readFromFile();
    }
    
     public ArrayList<Product> all(){
        return array;
    }
     
     //to get data from the array
     public Product get(int index){
        return array.get(index);
    }
     
     public Product findid(int id){
        for(Product p: array){
            if(p.getProductID()==id){
                return p;
            }
        }
        return null;
    }
     
     public Product findProductName(String ProductName){
        for(Product p: array){
            if(p.getProductName().equals(ProductName)){
                return p;
            }
        }
        return null;
    }
     
     public Product findProductNameWithIgnore(String productname, int productid){
        for(Product p: array){
            if(p.getProductID() != productid && p.getProductName().equals(productname)){
                return p;
            }
        }
        return null;
    }
     
     public Product add(Product product){
        product.setProductID(newid);
        newid += 1;
        array.add(product);
        fireTableRowsInserted(array.size() - 1, array.size() - 1);
        writeToFile();
        return product;
    }
     
     public Product set(Product product){
        for(int i=0; i < array.size(); i++){
            if(array.get(i).getProductID() == product.getProductID()){
                Product p = array.set(i, product);
                fireTableRowsUpdated(i,i);
                writeToFile();
                return p;
            }
        }
        return null;
    }
     
      public Product remove(Product product){
        for(int i = 0; i < array.size(); i++){
            if(array.get(i).getProductID() == product.getProductID()){
                Product p = array.remove(i);
                fireTableRowsDeleted(i, i);
                writeToFile();
                return p;
            }
        }
        return null;
    }
      
      public void readFromFile(){
        try{
            Scanner scanner = new Scanner(new File ("product.txt"));
            newid = Integer.parseInt(scanner.nextLine());
            scanner.nextLine();
            while (scanner.hasNext()){
                Product p = new Product();
                p.setProductID(Integer.parseInt(scanner.nextLine()));
                p.setProductName(scanner.nextLine());
                p.setCategory(scanner.nextLine());
                p.setPrice(Integer.parseInt(scanner.nextLine()));
                p.setQuantity(Integer.parseInt(scanner.nextLine()));
                p.setSupplierInfo(scanner.nextLine());
                p.setBrand(scanner.nextLine());
                scanner.nextLine();
                array.add(p);
            }
            scanner.close();
        }
        catch(FileNotFoundException ex){
        }
    }
      
      private void writeToFile(){
        try{
            PrintWriter writer = new PrintWriter(new FileWriter("product.txt"));
            writer.println(newid);
            writer.println();
            for(Product p : array){
                writer.println(p.getProductID());
                writer.println(p.getProductName());
                writer.println(p.getCategory());
                writer.println(p.getPrice());
                writer.println(p.getQuantity());
                writer.println(p.getSupplierInfo());
                writer.println(p.getBrand());
                writer.println();
            }
            writer.close();
        }
        catch(IOException ex){
        }
    }
     

    @Override
    public int getRowCount() {
        return array.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0: return array.get(row).getProductID();
            case 1: return array.get(row).getProductName();
            case 2: return array.get(row).getCategory();
            case 3: return array.get(row).getPrice();
            case 4: return array.get(row).getQuantity();
            case 5: return array.get(row).getSupplierInfo();
            case 6: return array.get(row).getBrand();
        }
        return null;
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "Product ID";
            case 1: return "Product Name";
            case 2: return "Category";
            case 3: return "Price";
            case 4: return "Quantity";
            case 5: return "SupplierInfo";
            case 6: return "Brand";
        }
        return null;
    }

    

    
    
}
