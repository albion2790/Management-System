/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author someone
 */
public class LogRecord_Model extends AbstractTableModel{

    private ArrayList<LogRecord> array;
    private int newid;
    
    public LogRecord_Model(){
        super();
        array = new ArrayList<LogRecord>();
        newid = 001;
        readFromFile();
    }
    public ArrayList<LogRecord> all(){
        return array;
    }
    
    public LogRecord get(int index){
        return array.get(index);
    }
    
     public LogRecord add(LogRecord logrecord){
        logrecord.setLogID(newid);
        newid += 1;
        array.add(logrecord);
        fireTableRowsInserted(array.size() - 1, array.size() - 1);
        writeToFile();
        return logrecord;
    }
     
     public void readFromFile(){
        try{
            Scanner scanner = new Scanner(new File ("logrecord.txt"));
            newid = Integer.parseInt(scanner.nextLine());
            scanner.nextLine();
            while (scanner.hasNext()){
                LogRecord l = new LogRecord();
                l.setLogID(Integer.parseInt(scanner.nextLine()));
                l.setUserID(Integer.parseInt(scanner.nextLine()));
                l.setUsername(scanner.nextLine());
                l.setRole(scanner.nextLine());
                l.setAction(scanner.nextLine());
                l.setDateTime(scanner.nextLine());
                scanner.nextLine();
                array.add(l);
            }
            scanner.close();
        }
        catch(FileNotFoundException ex){
        }
    }
      
      private void writeToFile(){
        try{
            PrintWriter writer = new PrintWriter(new FileWriter("logrecord.txt"));
            writer.println(newid);
            writer.println();
            for(LogRecord l : array){
                writer.println(l.getLogID());
                writer.println(l.getUserID());
                writer.println(l.getUsername());
                writer.println(l.getRole());
                writer.println(l.getAction());
                writer.println(l.getDateTime());
                writer.println();
            }
            writer.close();
        }
        catch(IOException ex){
        }
    }
     @Override
    public int getRowCount() {
        return array.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0: return array.get(row).getUserID();
            case 1: return array.get(row).getUsername();
            case 2: return array.get(row).getRole();
            case 3: return array.get(row).getAction();
            case 4: return array.get(row).getDateTime();
        }
        return null;
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "User ID";
            case 1: return "Username";
            case 2: return "Role";
            case 3: return "Action";
            case 4: return "Date/Time";
        }
        return null;
    }
}
