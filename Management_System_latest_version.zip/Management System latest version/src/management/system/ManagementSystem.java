/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import java.util.ArrayList;

/**
 *
 * @author TP048347
 */
public class ManagementSystem {
    public static Admin_Page admin_page;
    public static Product_Manager_Page product_manager_page;
    public static Login_Page login_page;
    public static User currentuser;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //instanciating 
        User_Model user_model = new User_Model();
        Product_Model product_model = new Product_Model();
        Category_Model category_model = new Category_Model();
        Supplier_Model supplier_model = new Supplier_Model();
        Catalogue_Model catalogue_model = new Catalogue_Model();
        LogRecord_Model logrecord_model = new LogRecord_Model();
        admin_page = new Admin_Page(user_model, supplier_model, product_model, category_model, catalogue_model, logrecord_model);
        login_page = new Login_Page(user_model, logrecord_model);
        product_manager_page = new Product_Manager_Page(logrecord_model,product_model, supplier_model, category_model, catalogue_model, user_model);
        login_page.setVisible(true);
          
       }
    
}
