/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author someone
 */
public class Supplier_Model extends AbstractTableModel{

    private ArrayList<Supplier> array;
    private int newid;
    
    public Supplier_Model(){
        super();
        array = new ArrayList<Supplier>();
        newid = 001;
        readFromFile();
    }
    
    public ArrayList<Supplier> all(){
        return array;
    }
    
    public Supplier get(int index){
        return array.get(index);
    }
    
     public Supplier findid(int id){
        for(Supplier s: array){
            if(s.getSupplierID()==id){
                return s;
            }
        }
        return null;
    }
    
     public Supplier findSupplierName(String SupplierName){
        for(Supplier s: array){
            if(s.getSupplierName().equals(SupplierName)){
                return s;
            }
        }
        return null;
    }
     
     public Supplier findSupplierNameWithIgnore(String Suppliername, int supplierid){
        for(Supplier p: array){
            if(p.getSupplierID() != supplierid && p.getSupplierName().equals(Suppliername)){
                return p;
            }
        }
        return null;
    }
     
     public Supplier add(Supplier supplier){
        supplier.setSupplierID(newid);
        newid += 1;
        array.add(supplier);
        fireTableRowsInserted(array.size() - 1, array.size() - 1);
        writeToFile();
        return supplier;
    }
     
     public Supplier set(Supplier supplier){
        for(int i=0; i < array.size(); i++){
            if(array.get(i).getSupplierID() == supplier.getSupplierID()){
                Supplier s = array.set(i, supplier);
                fireTableRowsUpdated(i,i);
                writeToFile();
                return s;
            }
        }
        return null;
    }
     
      public Supplier remove(Supplier supplier){
        for(int i = 0; i < array.size(); i++){
            if(array.get(i).getSupplierID() == supplier.getSupplierID()){
                Supplier s = array.remove(i);
                fireTableRowsDeleted(i, i);
                writeToFile();
                return s;
            }
        }
        return null;
    }
      
      public void readFromFile(){
        try{
            Scanner scanner = new Scanner(new File ("supplier.txt"));
            newid = Integer.parseInt(scanner.nextLine());
            scanner.nextLine();
            while (scanner.hasNext()){
                Supplier s = new Supplier();
                s.setSupplierID(Integer.parseInt(scanner.nextLine()));
                s.setSupplierName(scanner.nextLine());
                s.setSupplierCompany(scanner.nextLine());
                s.setStatus(scanner.nextLine());
                scanner.nextLine();
                array.add(s);
            }
            scanner.close();
        }
        catch(FileNotFoundException ex){
        }
    }
      
       private void writeToFile(){
        try{
            PrintWriter writer = new PrintWriter(new FileWriter("supplier.txt"));
            writer.println(newid);
            writer.println();
            for(Supplier s: array){
                writer.println(s.getSupplierID());
                writer.println(s.getSupplierName());
                writer.println(s.getSupplierCompany());
                writer.println(s.getStatus());
                writer.println();
            }
            writer.close();
        }
        catch(IOException ex){
        }
    }
    @Override
    public int getRowCount() {
        return array.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0: return array.get(row).getSupplierID();
            case 1: return array.get(row).getSupplierName();
            case 2: return array.get(row).getSupplierCompany();
            case 3: return array.get(row).getStatus();
        }
        return null;
    }
    
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "Supplier ID";
            case 1: return "Supplier Name";
            case 2: return "Supplier Company";
            case 3: return "Status";
        }
        return null;
    }
}
