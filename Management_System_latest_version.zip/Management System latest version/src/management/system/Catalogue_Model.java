/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author someone
 */
public class Catalogue_Model extends AbstractTableModel {

    private ArrayList<FestivalProducts> array;
    private int newid;
    
    public Catalogue_Model(){
        super();
        array = new ArrayList<FestivalProducts>();
        newid = 001;
        readFromFile();
    }
    
    public ArrayList<FestivalProducts> all(){
        return array;
    }
    
    public FestivalProducts get(int index){
        return array.get(index);
    }
    
     public FestivalProducts findid(int id){
        for(FestivalProducts f: array){
            if(f.getCatalogueID()==id){
                return f;
            }
        }
        return null;
    }
     
     public  FestivalProducts saleStart(int startdate){
        for(FestivalProducts f: array){
            if(f.getSaleStart().equals(startdate)){
                return f;
            }
        }
        return null;
    }
     
      public  FestivalProducts saleEnd(int enddate){
        for(FestivalProducts f: array){
            if(f.getSaleEnd().equals(enddate)){
                return f;
            }
        }
        return null;
    }
      
       public FestivalProducts add(FestivalProducts festivalproducts){
        festivalproducts.setCatalogueID(newid);
        newid += 1;
        array.add(festivalproducts);
        fireTableRowsInserted(array.size() - 1, array.size() - 1);
        writeToFile();
        return festivalproducts;
    }
       
        public FestivalProducts set(FestivalProducts festivalproducts){
        for(int i=0; i < array.size(); i++){
            if(array.get(i).getCatalogueID() == festivalproducts.getCatalogueID()){
                FestivalProducts f = array.set(i, festivalproducts);
                fireTableRowsUpdated(i,i);
                writeToFile();
                return f;
            }
        }
        return null;
    }
        
        public FestivalProducts remove(FestivalProducts festivalproducts){
        for(int i = 0; i < array.size(); i++){
            if(array.get(i).getCatalogueID() == festivalproducts.getCatalogueID()){
                FestivalProducts f = array.remove(i);
                fireTableRowsDeleted(i, i);
                writeToFile();
                return f;
            }
        }
        return null;
    }
        
        public void readFromFile(){
        try{
            Scanner scanner = new Scanner(new File ("catalogue.txt"));
            newid = Integer.parseInt(scanner.nextLine());
            scanner.nextLine();
            while (scanner.hasNext()){
                FestivalProducts f = new FestivalProducts();
                f.setCatalogueID(Integer.parseInt(scanner.nextLine()));
                f.setProductID(Integer.parseInt(scanner.nextLine()));
                f.setPrice(Integer.parseInt(scanner.nextLine()));
                f.setFestival(scanner.nextLine());
                f.setSaleStart(scanner.nextLine());
                f.setSaleEnd(scanner.nextLine());
                scanner.nextLine();
                array.add(f);
            }
            scanner.close();
        }
        catch(FileNotFoundException ex){
        }
    }
        
        private void writeToFile(){
        try{
            PrintWriter writer = new PrintWriter(new FileWriter("catalogue.txt"));
            writer.println(newid);
            writer.println();
            for(FestivalProducts f: array){
                writer.println(f.getCatalogueID());
                writer.println(f.getProductID());
                writer.println(f.getPrice());
                writer.println(f.getFestival());
                writer.println(f.getSaleStart());
                writer.println(f.getSaleEnd());
                writer.println();
            }
            writer.close();
        }
        catch(IOException ex){
        }
    }
    @Override
    public int getRowCount() {
        return array.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0: return array.get(row).getCatalogueID();
            case 1: return array.get(row).getProductID();
            case 2: return array.get(row).getPrice();
            case 3: return array.get(row).getFestival();
            case 4: return array.get(row).getSaleStart();
            case 5: return array.get(row).getSaleEnd();
        }
        return null;   
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "Catalogue ID";
            case 1: return "Product ID";
            case 2: return "Price";
            case 3: return "Festival";
            case 4: return "Start Sale";
            case 5: return "End Sale";
        }
        return null;
    }
}
