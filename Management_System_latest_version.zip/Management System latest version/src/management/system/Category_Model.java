/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author someone
 */
//Creating an array list for the category model and reading from file by using a method
//called readFromFile
public class Category_Model {
    private DefaultComboBoxModel<String> array;
    
    public Category_Model(){
        
        array = new DefaultComboBoxModel<>();
        
        readFromFile();
        
    }
    public DefaultComboBoxModel<String> all(){
        return array;
    }
     
     //to get data from the array
     public String get(int index){
        return array.getElementAt(index);
    }
     public void remove(String category){
         array.removeElement(category);
         writeToFile();
    }
      public void add(String category){
       array.addElement(category);
       writeToFile();
    }
      public void readFromFile(){
        try{
            Scanner scanner = new Scanner(new File ("category.txt"));
           
            while (scanner.hasNext()){
                
                array.addElement(scanner.nextLine());
            }
            scanner.close();
        }
        catch(FileNotFoundException ex){
        }
    }
      
      private void writeToFile(){
        try{
            PrintWriter writer = new PrintWriter(new FileWriter("category.txt"));
           
            for(int i = 0; i<array.getSize(); i ++){
                writer.println(array.getElementAt(i));
            }
            writer.close();
        }
        catch(IOException ex){
        }
    }
}
