/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.system;

import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;
//model
/**
 *
 * @author TP048347
 */
//inherting the attributes in Login_Page

    
public class User_Model extends AbstractTableModel{

    private ArrayList<User> array;
    private int newid;
    
    public User_Model(){
        super();
        array = new ArrayList<User>();
        newid = 001;
        readFromFile();
    }
    
    public ArrayList<User> all(){
        return array;
    }
    
    public User get(int index){
        return array.get(index);
    }
    
    public User findid(int id){
        for(User u: array){
            if(u.getId()==id){
                return u;
            }
        }
        return null;
    }
    
    public User findUsername(String username){
        for(User u: array){
            if(u.getUsername().equals(username)){
                return u;
            }
        }
        return null;
    }
    
    public User findUsernameWithIgnore(String username, int userid){
        for(User u: array){
            if(u.getUserid() != userid && u.getUsername().equals(username)){
                return u;
            }
        }
        return null;
    }
    
    public User add(User user){
        user.setId(newid);
        newid += 1;
        array.add(user);
        fireTableRowsInserted(array.size() - 1, array.size() - 1);
        writeToFile();
        return user;
    }
    
    public User set(User user){
        for(int i=0; i < array.size(); i++){
            if(array.get(i).getId() == user.getId()){
                User u = array.set(i, user);
                fireTableRowsUpdated(i,i);
                writeToFile();
                return u;
            }
        }
        return null;
    }
    
    public User remove(User user){
        for(int i = 0; i < array.size(); i++){
            if(array.get(i).getId() == user.getId()){
                User u = array.remove(i);
                fireTableRowsDeleted(i, i);
                writeToFile();
                return u;
            }
        }
        return null;
    }
    
    public void readFromFile(){
        try{
            Scanner scanner = new Scanner(new File ("user.txt"));
            newid = Integer.parseInt(scanner.nextLine());
            scanner.nextLine();
            while (scanner.hasNext()){
                User u = new User();
                u.setId(Integer.parseInt(scanner.nextLine()));
                u.setName(scanner.nextLine());
                u.setAddress(scanner.nextLine());
                u.setEmail(scanner.nextLine());
                u.setUsername(scanner.nextLine());
                u.setPassword(scanner.nextLine());
                u.setRole(scanner.nextLine());
                u.setStatus(scanner.nextLine());
                scanner.nextLine();
                array.add(u);
                
            }
            scanner.close();
        }
        catch(FileNotFoundException ex){
        }
    }
    
    private void writeToFile(){
        try{
            PrintWriter writer = new PrintWriter(new FileWriter("user.txt"));
            writer.println(newid);
            writer.println();
            for(User u: array){
                writer.println(u.getId());
                writer.println(u.getName());
                writer.println(u.getAddress());
                writer.println(u.getEmail());
                writer.println(u.getUsername());
                writer.println(u.getPassword());
                writer.println(u.getRole());
                writer.println(u.getStatus());
                writer.println();
            }
            writer.close();
        }
        catch(IOException ex){
        }
    }
    @Override
    public int getRowCount() {
        return array.size();
    }
    
    @Override
    public int getColumnCount() {
        return 8;
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0: return array.get(row).getId();
            case 1: return array.get(row).getName();
            case 2: return array.get(row).getAddress();
            case 3: return array.get(row).getEmail();
            case 4: return array.get(row).getUsername();
            case 5: return array.get(row).getPassword();
            case 6: return array.get(row).getStatus();
            case 7: return array.get(row).getRole();
        }
        return null;
    }
    
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "User ID";
            case 1: return "Name";
            case 2: return "Address";
            case 3: return "Email";
            case 4: return "Username";
            case 5: return "Password";
            case 6: return "Status";
            case 7: return "Role";
        }
        return null;
    }
}



    
